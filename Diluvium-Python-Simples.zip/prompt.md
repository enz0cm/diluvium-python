# Registro de uso de inteligência artificial

**Diluvium · Computational Thinking with Python · Global Solution 2026.2**

## Ferramenta e finalidade

Foi usado o ChatGPT (Codex) para interpretar o documento do grupo e os slides da disciplina, implementar a aplicação em Python, executar verificações e preparar a documentação da entrega. A busca na web foi usada para conferir as referências geográficas dos trechos dos sensores simulados.

## Pedidos enviados

> Nossa ideia, é um sistema de monitoramento de enchentes na regiao leia o doc pdf e faça oq ta pedindo, a materia é computional thinking with python

O pedido veio acompanhado do PDF *Diluvium — o que cada matéria vai fazer* e de três slides da atividade com os requisitos da aplicação, do registro de IA e do ZIP.

### Pedido de revisão

> eu achei algumas partes do codigo meio complexa e que a gnt nao aprendeu, faça de uma maneira mais simples, use oq esta nas documentacoes e algumas outras coisas, mas evite coisas complexas

## Funcionalidades desenvolvidas com IA

- Menu, cadastro de sensores, registro de leituras e validação de entradas.
- Classificação por percentual da cota, estimativa com média móvel e antecipação do estado.
- Cálculo de vazão, uso da drenagem, volume que chega à rede e volume excedente.
- Simulação de chuva nos três sensores iniciais, histórico e relatório por sensor.
- Registro e confirmação de relatos, estado do trecho e persistência em JSON.
- Revisão em um único `main.py`, com validações feitas na entrada, laços explícitos e fórmulas escritas em funções.

## Verificação e ajustes

O Codex executou o programa pelo terminal em cópias da base e conferiu os resultados gravados em JSON. A execução foi feita em Python 3.12 e os arquivos também tiveram sua sintaxe conferida para Python 3.10. As verificações incluíram estes casos.

| Caso | Resultado conferido |
| --- | --- |
| Limites e antecipação | 50% entrou em Atenção e 70% em Crítico. Na chuva simulada, Atenção apareceu a 47% e Crítico a 63% pela antecipação. |
| Cálculo com o S01 | 35 mm/h resultou em cerca de 155,6 L/s e 51,9% de uso. Em outro caso, 90 mm/h por 5 minutos resultou em 120.000 L de entrada e 30.000 L de excedente. |
| Simulação e persistência | A base inicial recebeu 33 leituras. O relatório recuperou o histórico em outra execução. |
| Compatibilidade da revisão | A versão revisada abriu o JSON da versão inicial, manteve os sensores, as leituras e o relato confirmado e registrou outra simulação. |
| Entradas e arquivo | Foram testados ID repetido, números inválidos, área e capacidade não positivas, coeficiente fora da faixa, data inválida, data fora de ordem, arquivo ausente e JSON malformado. |
| Relatos | Dois relatos confirmados no mesmo trecho produziram o estado Alagado por relatos. Quando a leitura chegou à cota, o painel indicou a cota atingida. |

O cálculo percentual foi ajustado para evitar que a imprecisão de ponto flutuante colocasse uma leitura exatamente em 50%, 70% ou 100% abaixo do limite. A base do ZIP permaneceu com os três sensores iniciais e o histórico vazio após os testes.

O grupo pode repetir o roteiro do `readme.md` e registrar aqui a execução e os ajustes feitos pelos integrantes. Este registro descreve as verificações executadas pelo Codex.

## Análise crítica

A IA ajudou a transformar o PDF em funções e os exemplos de cálculo em casos de teste. O grupo pediu a revisão porque algumas estruturas da primeira versão ainda não tinham sido estudadas. O código revisado usa os recursos dos slides e concentra os controles de horário e de arquivo em poucas funções da biblioteca padrão. Um cuidado foi aplicar a faixa de 0 a 100 ao coeficiente digitado e permitir que os percentuais calculados ultrapassem 100 nos casos de transbordamento e sobrecarga. As simulações usam valores de exemplo. A aplicação dessas regras em um trecho real depende da medição da cota, da capacidade da drenagem e da calibração em campo.
