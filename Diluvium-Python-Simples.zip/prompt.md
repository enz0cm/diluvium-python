# Uso de IA no Diluvium

O ChatGPT (Codex) ajudou a montar a versão inicial e sugeriu correções e melhorias na revisão do projeto, como reunir o código em um único arquivo e deixar as validações mais claras.

## Pedidos feitos à IA

- Ler o PDF da atividade e montar o sistema de monitoramento para a disciplina de Python.
- Simplificar o código usando os recursos vistos na disciplina.
- Resumir o registro de uso de IA.

## Conferência

A versão enviada pelo grupo tinha 33 leituras gravadas. Na revisão, o programa foi executado e o relatório do sensor S01 foi consultado com esses dados.

A IA ajudou a organizar o código. A execução com dados simulados serviu para conferir o funcionamento do programa.
