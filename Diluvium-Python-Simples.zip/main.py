"""Diluvium — simulação de monitoramento de enchentes."""

import json
import os
from datetime import datetime, timedelta, timezone
from math import isfinite


# O JSON fica na mesma pasta que este arquivo.
PASTA = os.path.dirname(os.path.abspath(__file__))
ARQUIVO_DADOS = os.path.join(PASTA, "dados.json")
IDS_SENSORES = ("S01", "S02", "S03", "S04", "S05")
ORDEM_ESTADOS = {"normal": 0, "atencao": 1, "critico": 2}
NOMES_SENSOR = {"normal": "Normal", "atencao": "Atenção", "critico": "Crítico"}
NOMES_TRECHO = {
    "normal": "Sem alerta | verde",
    "atencao": "Atenção | amarelo",
    "critico": "Crítico | vermelho",
}

# Cada par tem a chuva (mm/h) e o nível (% da cota).
PERFIL_CHUVA = [
    (0, 20), (45, 47), (90, 63), (130, 82), (160, 105), (115, 88),
    (70, 72), (35, 65), (15, 48), (5, 38), (0, 29),
]


def carregar_dados(caminho):
    try:
        with open(caminho, "r", encoding="utf-8") as arquivo:
            dados = json.load(arquivo)
    except FileNotFoundError:
        print("Arquivo dados.json ausente. A base será criada no primeiro cadastro.")
        return {"sensores": {}, "leituras": [], "relatos": []}

    if not isinstance(dados, dict):
        raise ValueError("A base do Diluvium deve ser um dicionário.")
    if not isinstance(dados.get("sensores"), dict):
        raise ValueError("O campo sensores deve ser um dicionário.")
    if not isinstance(dados.get("leituras"), list) or not isinstance(dados.get("relatos"), list):
        raise ValueError("Os campos leituras e relatos devem ser listas.")
    return dados


def salvar_dados(caminho, dados):
    # A gravação termina em um arquivo temporário antes de substituir o JSON.
    temporario = f"{caminho}.{os.getpid()}.tmp"
    try:
        with open(temporario, "w", encoding="utf-8") as arquivo:
            json.dump(dados, arquivo, indent=2, ensure_ascii=False, allow_nan=False)
            arquivo.write("\n")
        os.replace(temporario, caminho)
    except (ValueError, OSError):
        if os.path.isfile(temporario):
            os.remove(temporario)
        raise


def ler_numero(pergunta, minimo=0, maximo=None, positivo=False):
    while True:
        texto = input(pergunta).replace(",", ".")
        try:
            numero = float(texto)
        except ValueError:
            print("Digite um número válido.")
            continue

        if not isfinite(numero):
            print("Digite um número finito.")
        elif positivo and numero <= 0:
            print("O valor deve ser maior que zero.")
        elif numero < minimo:
            print(f"O valor mínimo é {minimo}.")
        elif maximo is not None and numero > maximo:
            print(f"O valor máximo é {maximo}.")
        else:
            return numero


def escolher_sensor(sensores):
    if not sensores:
        raise ValueError("Cadastre um sensor pela opção 2 para continuar.")
    for sensor in sensores.values():
        print(sensor["id"], "|", sensor["corrego"], "|", sensor["rua"])
    id_sensor = input("ID do sensor > ").strip().upper()
    if id_sensor not in sensores:
        raise ValueError("Escolha um dos IDs exibidos.")
    return sensores[id_sensor]


def cadastrar_sensor(sensores):
    if len(sensores) == len(IDS_SENSORES):
        raise ValueError("Os cinco IDs da rede estão em uso.")
    id_sensor = input("Novo ID (S01 a S05) > ").strip().upper()
    if id_sensor in sensores:
        raise ValueError(f"O ID {id_sensor} já está cadastrado.")
    if id_sensor not in IDS_SENSORES:
        raise ValueError("Informe um ID de S01 a S05.")

    opcao = input("Córrego [1 Ipiranga | 2 Moinho Velho] > ").strip()
    if opcao == "1":
        corrego = "Ipiranga"
    elif opcao == "2":
        corrego = "Moinho Velho"
    else:
        raise ValueError("Escolha 1 para Ipiranga ou 2 para Moinho Velho.")

    rua = input("Rua ou cruzamento > ").strip()
    if rua == "":
        raise ValueError("Informe a rua do trecho.")
    latitude = ler_numero("Latitude > ", -90, 90)
    longitude = ler_numero("Longitude > ", -180, 180)
    coordenadas = (latitude, longitude)
    cota = ler_numero("Cota de transbordamento (cm) > ", positivo=True)
    area = ler_numero("Área de contribuição (m²) > ", positivo=True)
    coeficiente = ler_numero("Coeficiente de escoamento (0 a 100%) > ", 0, 100)
    capacidade = ler_numero("Capacidade da drenagem (L/s) > ", positivo=True)

    return {
        "id": id_sensor, "corrego": corrego, "rua": rua,
        "lat": coordenadas[0], "lon": coordenadas[1], "cotaCm": cota,
        "areaContribuicaoM2": area, "coefEscoamento": coeficiente / 100,
        "capacidadeDrenagemLs": capacidade,
    }


def agora_local():
    # Os horários do projeto usam a hora de São Paulo (UTC-3).
    fuso_sao_paulo = timezone(timedelta(hours=-3))
    agora = datetime.now(fuso_sao_paulo)
    return agora.replace(tzinfo=None, microsecond=0)


def proximo_horario(leituras):
    sugerido = agora_local().replace(second=0)
    for leitura in leituras:
        horario = datetime.fromisoformat(leitura["dataHora"])
        horario = horario + timedelta(minutes=5)
        if horario > sugerido:
            sugerido = horario
    return sugerido


def ler_horario(historico):
    formato = "%Y-%m-%d %H:%M"
    sugerido = proximo_horario(historico)
    print("Horário sugerido", sugerido.strftime(formato))
    while True:
        texto = input("Data e hora (AAAA-MM-DD HH:MM ou Enter) > ").strip()
        if texto == "":
            return sugerido
        try:
            return datetime.strptime(texto, formato)
        except ValueError:
            print("Informe uma data válida no formato AAAA-MM-DD HH:MM.")


def historico_sensor(leituras, id_sensor):
    historico = []
    for leitura in leituras:
        if leitura["id"] == id_sensor:
            historico.append(leitura)
    return historico


def calcular_percentual(nivel, cota):
    # O arredondamento evita imprecisão nos limites de 50%, 70% e 100%.
    return round(nivel / cota * 100, 10)


def calcular_velocidade(historico, nivel, minutos):
    if not historico:
        return 0

    # [-3:] seleciona até as três últimas leituras da lista.
    niveis = []
    for leitura in historico[-3:]:
        niveis.append(leitura["nivelCm"])
    media_anterior = sum(niveis) / len(niveis)
    niveis.append(nivel)
    niveis = niveis[-3:]
    media_atual = sum(niveis) / len(niveis)
    return (media_atual - media_anterior) / minutos


def estimar_tempo(nivel, cota, velocidade):
    if nivel >= cota:
        return 0
    elif velocidade > 0.5:
        return (cota - nivel) / velocidade
    else:
        return None


def classificar_estado(percentual, tempo):
    if percentual >= 70:
        estado = "critico"
    elif percentual >= 50:
        estado = "atencao"
    else:
        estado = "normal"

    if tempo is not None and tempo < 30:
        if estado == "normal":
            estado = "atencao"
        elif estado == "atencao":
            estado = "critico"
    return estado


def estado_confirmado(estado, historico):
    if not historico:
        return estado

    anterior = historico[-1]["estado"]
    if ORDEM_ESTADOS[estado] >= ORDEM_ESTADOS[anterior]:
        return estado

    # Para baixar o estado, as duas leituras anteriores também devem
    # estar na nova faixa. A leitura atual completa a sequência de três.
    if len(historico) < 2:
        return anterior
    for leitura in historico[-2:]:
        faixa = classificar_estado(leitura["percentual"], leitura.get("tempoEstimadoMin"))
        if faixa != estado:
            return anterior
    return estado


def calcular_drenagem(sensor, chuva, segundos):
    area = sensor["areaContribuicaoM2"]
    coeficiente = sensor["coefEscoamento"]
    capacidade = sensor["capacidadeDrenagemLs"]
    vazao = chuva * area * coeficiente / 3600
    uso = vazao / capacidade * 100
    litros = vazao * segundos
    excedente = 0
    if vazao > capacidade:
        excedente = (vazao - capacidade) * segundos
    return vazao, uso, litros, excedente


def registrar_leitura(sensor, historico, horario, nivel, chuva):
    segundos = 0
    total = 0
    total_excedente = 0
    if historico:
        ultima = historico[-1]
        horario_anterior = datetime.fromisoformat(ultima["dataHora"])
        segundos = (horario - horario_anterior).total_seconds()
        if segundos <= 0:
            raise ValueError("O horário deve ser posterior ao da última leitura do sensor.")
        total = ultima["volumeAcumuladoL"]
        total_excedente = ultima.get("volumeExcedenteL", 0)

    cota = sensor["cotaCm"]
    percentual = calcular_percentual(nivel, cota)
    velocidade = calcular_velocidade(historico, nivel, segundos / 60)
    tempo = estimar_tempo(nivel, cota, velocidade)
    estado = classificar_estado(percentual, tempo)
    estado = estado_confirmado(estado, historico)
    vazao, uso, litros, excedente = calcular_drenagem(sensor, chuva, segundos)
    total = total + litros
    total_excedente = total_excedente + excedente

    for valor in (percentual, velocidade, tempo, vazao, uso, total, total_excedente):
        if valor is not None and not isfinite(valor):
            raise ValueError("O cálculo ficou fora da faixa numérica.")

    return {
        "id": sensor["id"], "dataHora": horario.isoformat(timespec="seconds"),
        "nivelCm": nivel, "percentual": percentual, "velocidadeCmMin": velocidade,
        "tempoEstimadoMin": tempo, "chuvaMmH": chuva, "vazaoEntradaLs": vazao,
        "percentualDrenagem": uso, "volumeAcumuladoL": total,
        "volumeExcedenteL": total_excedente, "estado": estado,
    }


def simular_chuva(sensores, leituras):
    if not sensores:
        raise ValueError("Cadastre um sensor antes de simular a chuva.")

    historicos = {}
    for id_sensor in sensores:
        historicos[id_sensor] = historico_sensor(leituras, id_sensor)

    novas_leituras = []
    horario = proximo_horario(leituras)
    for chuva, percentual in PERFIL_CHUVA:
        for id_sensor in sensores:
            sensor = sensores[id_sensor]
            historico = historicos[id_sensor]
            nivel = sensor["cotaCm"] * (percentual / 100)
            leitura = registrar_leitura(sensor, historico, horario, nivel, chuva)
            historico.append(leitura)
            novas_leituras.append(leitura)
        horario = horario + timedelta(minutes=5)
    return novas_leituras


def gerar_relatorio(historico):
    soma = 0
    maximo = 0
    pico_drenagem = 0
    criticas = 0
    episodios = 0
    estado_anterior = ""
    for leitura in historico:
        nivel = leitura["nivelCm"]
        soma = soma + nivel
        maximo = max(maximo, nivel)
        pico_drenagem = max(pico_drenagem, leitura["percentualDrenagem"])
        if leitura["estado"] == "critico":
            criticas = criticas + 1
            if estado_anterior != "critico":
                episodios = episodios + 1
        estado_anterior = leitura["estado"]

    ultima = historico[-1]
    return {
        "media": soma / len(historico), "maximo": maximo,
        "criticas": criticas, "episodios": episodios, "picoDrenagem": pico_drenagem,
        "total": ultima["volumeAcumuladoL"], "excedente": ultima.get("volumeExcedenteL", 0),
    }


def mostrar_leitura(leitura):
    estado = NOMES_SENSOR[leitura["estado"]]
    print(f"  Sensor {estado} | {leitura['dataHora']}")
    print(f"  Nível {leitura['nivelCm']:.1f} cm | {leitura['percentual']:.1f}% da cota")
    print(f"  Velocidade {leitura['velocidadeCmMin']:.2f} cm/min")
    tempo = leitura.get("tempoEstimadoMin")
    if tempo is None:
        print("  Tempo estimado até transbordar indisponível.")
    else:
        print(f"  Tempo estimado até transbordar {tempo:.1f} min")
    print(f"  Chuva {leitura['chuvaMmH']:.1f} mm/h | Vazão {leitura['vazaoEntradaLs']:.1f} L/s")
    print(f"  Uso da drenagem {leitura['percentualDrenagem']:.1f}%")
    if leitura["percentualDrenagem"] > 100:
        print("  A vazão de entrada supera a capacidade da drenagem.")


def mostrar_relatorio(dados):
    sensor = escolher_sensor(dados["sensores"])
    historico = historico_sensor(dados["leituras"], sensor["id"])
    if not historico:
        print("Sem leituras para este sensor.")
        return

    resumo = gerar_relatorio(historico)
    print(f"\nRelatório {sensor['id']} | {sensor['rua']}")
    print(f"Cota {sensor['cotaCm']} cm | Capacidade da drenagem {sensor['capacidadeDrenagemLs']} L/s")
    print(f"{len(historico)} leituras | Média {resumo['media']:.1f} cm | Máximo {resumo['maximo']:.1f} cm")
    print(f"Leituras em Crítico {resumo['criticas']} | Episódios em Crítico {resumo['episodios']}")
    print(f"Volume que chega à drenagem {resumo['total']:.1f} L")
    print(f"Volume excedente {resumo['excedente']:.1f} L")
    print(f"Pico de uso da drenagem {resumo['picoDrenagem']:.1f}%")
    print("\nÚltima leitura")
    mostrar_leitura(historico[-1])
    print("\nHistórico recente | Horário, cota, drenagem e estado")
    for leitura in historico[-11:]:
        estado = NOMES_SENSOR[leitura["estado"]]
        if leitura["percentual"] >= 100:
            estado = estado + " | Cota atingida"
        print(f"  {leitura['dataHora']} | {leitura['percentual']:.1f}% | "
              f"{leitura['percentualDrenagem']:.1f}% | {estado}")


def cadastrar_relato(relatos, id_sensor):
    descricao = input("Descreva a situação da rua, sem nomes ou telefones > ").strip()
    if descricao == "":
        raise ValueError("Escreva a descrição do relato.")
    maior_id = 0
    for relato in relatos:
        maior_id = max(maior_id, relato["id"])

    return {
        "id": maior_id + 1, "sensorId": id_sensor,
        "dataHora": agora_local().isoformat(timespec="seconds"),
        "descricao": descricao, "confirmado": False,
    }


def listar_relatos(relatos):
    if not relatos:
        print("Nenhum relato registrado.")
    for relato in relatos:
        if relato["confirmado"]:
            situacao = "Confirmado"
        else:
            situacao = "Pendente"
        print(relato["id"], "|", relato["sensorId"], "|", relato["dataHora"], "|", situacao)
        print(" ", relato["descricao"])


def confirmar_relato(relatos):
    if not relatos:
        raise ValueError("Cadastre um relato pela opção 6.")
    listar_relatos(relatos)
    try:
        numero = int(input("Número do relato > "))
    except ValueError:
        raise ValueError("Informe o número inteiro do relato.")

    for relato in relatos:
        if relato["id"] == numero:
            if relato["confirmado"]:
                raise ValueError(f"O relato {numero} já está confirmado.")
            relato["confirmado"] = True
            return relato
    raise ValueError(f"O relato {numero} não foi encontrado.")


def situacao_trecho(id_sensor, leitura, relatos, agora):
    if leitura is not None and leitura["percentual"] >= 100:
        return "Alagado | roxo | cota atingida na simulação"

    confirmados = 0
    uma_hora_atras = agora - timedelta(hours=1)
    for relato in relatos:
        if relato["sensorId"] == id_sensor and relato["confirmado"]:
            horario = datetime.fromisoformat(relato["dataHora"])
            if uma_hora_atras <= horario <= agora:
                confirmados = confirmados + 1
    if confirmados >= 2:
        return "Alagado | roxo | relatado por moradores"
    if leitura is not None:
        return NOMES_TRECHO[leitura["estado"]]
    return "Sem leituras"


def painel_sensores(dados):
    print("\nPainel dos sensores")
    if not dados["sensores"]:
        print("Nenhum sensor cadastrado. Use a opção 2.")
        return

    agora = agora_local()
    for sensor in dados["sensores"].values():
        print(sensor["id"], "|", sensor["corrego"], "|", sensor["rua"])
        print("  Coordenadas", sensor["lat"], sensor["lon"])
        historico = historico_sensor(dados["leituras"], sensor["id"])
        leitura = None
        if historico:
            leitura = historico[-1]
        situacao = situacao_trecho(sensor["id"], leitura, dados["relatos"], agora)
        print("  Trecho", situacao)
        if leitura is not None:
            mostrar_leitura(leitura)
        print()


def mostrar_menu():
    print("\nDILUVIUM | Monitoramento simulado de enchentes")
    print("1 - Painel dos sensores")
    print("2 - Cadastrar sensor")
    print("3 - Registrar leitura")
    print("4 - Simular chuva")
    print("5 - Relatório por sensor")
    print("6 - Cadastrar relato de morador")
    print("7 - Consultar relatos")
    print("8 - Confirmar relato")
    print("0 - Sair")


def main():
    dados = carregar_dados(ARQUIVO_DADOS)

    while True:
        mostrar_menu()
        opcao = input("Opção > ").strip()
        mudou = False
        try:
            match opcao:
                case "1":
                    painel_sensores(dados)
                case "2":
                    sensor = cadastrar_sensor(dados["sensores"])
                    dados["sensores"][sensor["id"]] = sensor
                    print(f"Novo sensor {sensor['id']}.")
                    mudou = True
                case "3":
                    sensor = escolher_sensor(dados["sensores"])
                    historico = historico_sensor(dados["leituras"], sensor["id"])
                    horario = ler_horario(historico)
                    nivel = ler_numero("Nível da água (cm) > ")
                    chuva = ler_numero("Intensidade da chuva (mm/h) > ")
                    leitura = registrar_leitura(sensor, historico, horario, nivel, chuva)
                    dados["leituras"].append(leitura)
                    mostrar_leitura(leitura)
                    mudou = True
                case "4":
                    novas = simular_chuva(dados["sensores"], dados["leituras"])
                    for leitura in novas:
                        dados["leituras"].append(leitura)
                    print(f"Chuva simulada. {len(novas)} leituras em passos de 5 minutos.")
                    print("Use a opção 5 para ver o histórico e os picos por sensor.")
                    mudou = True
                case "5":
                    mostrar_relatorio(dados)
                case "6":
                    sensor = escolher_sensor(dados["sensores"])
                    relato = cadastrar_relato(dados["relatos"], sensor["id"])
                    dados["relatos"].append(relato)
                    print(f"Relato {relato['id']} pendente de confirmação.")
                    mudou = True
                case "7":
                    listar_relatos(dados["relatos"])
                case "8":
                    relato = confirmar_relato(dados["relatos"])
                    print(f"Relato {relato['id']} confirmado.")
                    mudou = True
                case "0":
                    print("Diluvium encerrado.")
                    return
                case _:
                    print("Opção inválida. Escolha um número de 0 a 8.")
        except (ValueError, OverflowError) as erro:
            print(erro)

        if mudou:
            try:
                salvar_dados(ARQUIVO_DADOS, dados)
                print("Dados salvos em dados.json.")
            except (OSError, ValueError):
                print("Falha ao salvar. Recarregando a última versão gravada.")
                dados = carregar_dados(ARQUIVO_DADOS)


if __name__ == "__main__":
    try:
        main()
    except (OSError, ValueError, KeyError, TypeError) as erro:
        print("Verifique o arquivo dados.json.", erro)
    except (EOFError, KeyboardInterrupt):
        print("\nDiluvium encerrado.")
