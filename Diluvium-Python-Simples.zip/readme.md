# Diluvium

**Global Solution 2026.2 · CitizenTech · Computational Thinking with Python**

O Diluvium simula o monitoramento de enchentes em trechos dos córregos Ipiranga e Moinho Velho, em São Paulo. Pelo terminal, é possível acompanhar a altura da água, estimar o tempo até o transbordamento, calcular a carga da drenagem e registrar relatos de moradores.

A base começa com três sensores simulados. As coordenadas são aproximadas. As cotas, as áreas de contribuição, os coeficientes de escoamento e as capacidades da drenagem são valores de exemplo.

| ID | Córrego | Trecho |
| --- | --- | --- |
| `S01` | Moinho Velho | Rua das Juntas Provisórias × Rua Dois de Julho |
| `S02` | Ipiranga | Praça Leonor Kauppa |
| `S03` | Ipiranga | Rua Coronel Diogo |

## Como executar

1. Extraia o ZIP e abra a pasta completa no PyCharm em **File → Open**.
2. Selecione um interpretador **Python 3.10 ou superior**. Clique com o botão direito em `main.py` e escolha **Run 'main'**.
3. Digite o número da opção e pressione Enter na janela **Run**. Nos campos numéricos, use ponto ou vírgula decimal, sem separador de milhar.

No terminal, execute `python main.py` dentro da pasta do projeto. O programa usa a biblioteca padrão do Python e funciona localmente.

## Menu

| Opção | O que faz |
| --- | --- |
| 1 | Exibe o estado de cada trecho, o nível, a velocidade da água, o tempo estimado até transbordar e o uso da drenagem. |
| 2 | Cadastra um sensor com rua, coordenadas, cota, área, coeficiente de escoamento e capacidade da drenagem. |
| 3 | Registra nível em cm e intensidade de chuva em mm/h. A data pode ser digitada ou aceita com Enter. |
| 4 | Simula uma chuva em todos os sensores, com 11 leituras por sensor e intervalos de 5 minutos. |
| 5 | Mostra média e máximo do nível, leituras e episódios em Crítico, volumes e histórico recente de um sensor. |
| 6 | Registra um relato associado a um trecho, com descrição e horário. |
| 7 | Consulta os relatos e suas situações. |
| 8 | Confirma um relato pendente. |
| 0 | Encerra o programa. |

## Regras da simulação

O percentual da cota é `nível em cm ÷ cota em cm × 100`. As faixas abaixo são o padrão do grupo. O primeiro limite sinaliza a subida da água e o segundo marca a condição crítica antes da cota de transbordamento.

| Código | Faixa de referência | Nome e cor no mapa |
| --- | --- | --- |
| `normal` | De 0% a menos de 50% | Sem alerta · verde |
| `atencao` | De 50% a menos de 70% | Atenção · amarelo |
| `critico` | A partir de 70% | Crítico · vermelho |

- **Velocidade e antecipação.** A velocidade em cm/min é a diferença entre duas médias móveis consecutivas dividida pelo intervalo em minutos. A janela usa até três leituras. Quando a subida supera 0,5 cm/min, o tempo estimado é `(cota − nível atual) ÷ velocidade`. Um tempo inferior a 30 minutos sobe o estado em um nível. Os limites de velocidade e tempo são parâmetros provisórios da simulação.
- **Estabilidade.** As elevações são aplicadas na leitura atual. Uma redução exige três leituras seguidas com a mesma classificação inferior.
- **Alagamento.** O painel mostra `Alagado` em roxo quando o nível chega à cota ou quando há dois relatos confirmados no mesmo trecho. O painel identifica `relatado por moradores` quando o estado vem dos relatos. A janela de uma hora para relatos confirmados é um parâmetro do protótipo. Os relatos guardam apenas a descrição, o trecho, o horário e a situação da confirmação, além do identificador.

### Drenagem

Um milímetro de chuva sobre 1 m² equivale a 1 litro. O programa aplica as seguintes contas a cada leitura.

| Medida | Cálculo |
| --- | --- |
| Vazão de entrada em L/s | `chuva em mm/h × área em m² × coeficiente ÷ 3.600` |
| Uso da drenagem em % | `vazão de entrada ÷ capacidade em L/s × 100` |
| Litros recebidos no intervalo | `vazão de entrada × duração em segundos` |
| Litros excedentes no intervalo | `máximo(0, vazão de entrada − capacidade) × duração em segundos` |

A integração usa a vazão da leitura atual como constante no intervalo desde a leitura anterior do mesmo sensor. A primeira leitura registra os volumes em zero. O relatório soma os intervalos observados. No S01, 35 mm/h resulta em cerca de 155,6 L/s, ou 51,9% da capacidade. A drenagem acima de 100% recebe um destaque no painel. O estado do sensor segue o nível e a regra de antecipação.

## Demonstração rápida

1. Use **4** em uma base recém-extraída. O programa registra 33 leituras, com 11 leituras de cada sensor.
2. Use **5**, informe `S01` e veja a passagem por Atenção a 47% e por Crítico a 63% pela regra de antecipação. No pico, o nível chega a 105% da cota e a drenagem passa de 100%.
3. Use **6** duas vezes para criar dois relatos simulados de um mesmo trecho. Confirme ambos pela opção **8** e consulte a opção **1**. O painel mostra **Alagado · relatado por moradores** quando a leitura mais recente do trecho está abaixo de 100%.
4. Saia com **0**, execute o programa novamente e consulte o relatório e os relatos para conferir a persistência.

Para conferir os limites por nível isoladamente, comece com uma cópia limpa e registre uma leitura de 100 cm no S01. A cota de 200 cm coloca a leitura em 50%, portanto em Atenção. Em outra cópia limpa, a leitura inicial de 140 cm entra em Crítico, com 70% da cota.

## Arquivos e conceitos

| Arquivo | Conteúdo |
| --- | --- |
| `main.py` | Menu em `match/case` dentro de um `while`, funções com parâmetros e retorno, cálculos e leitura e gravação do JSON. |
| `dados.json` | Sensores em um dicionário por ID, leituras em uma lista e relatos em uma lista. |
| `prompts.md` e `prompt.md` | Registro do uso de IA nas duas grafias indicadas na atividade. |

Em `main.py`, a função `main` contém o menu. `classificar_estado` aplica `if/elif/else` às faixas da cota e `calcular_drenagem` faz as contas de vazão e volume. Os laços `for` percorrem as leituras da simulação e do relatório. O cadastro monta uma tupla de coordenadas e grava os valores em `lat` e `lon`.

O `try/except` trata a conversão de números e datas, IDs repetidos e falhas no arquivo. O programa valida cota, área e capacidade positivas. O coeficiente é digitado em porcentagem de 0 a 100 e gravado como fração de 0 a 1. O percentual da cota e o uso da drenagem podem superar 100% para representar transbordamento e sobrecarga.

As leituras seguem os campos do documento do grupo. `tempoEstimadoMin` registra a projeção, com valor `null` quando ela está indisponível, e `volumeExcedenteL` guarda o excedente acumulado. Os horários seguem a hora de São Paulo. Os cadastros são gravados a cada operação. Se o arquivo estiver ausente, o primeiro cadastro cria uma base nova. Se o JSON estiver corrompido, o programa informa a falha e preserva o arquivo.

A versão revisada usa o mesmo formato de `dados.json`, inclusive para as leituras e os relatos da versão inicial. `datetime` calcula os intervalos, `math.isfinite` valida os valores numéricos e `os` localiza e atualiza o JSON na pasta do programa.

## Referências dos trechos

- O CGE identifica o cruzamento usado como referência para o S01. As coordenadas aproximadas foram tomadas no cruzamento mapeado. [CGE São Paulo](https://www.cgesp.org/v3/noticias.jsp?id=54363) · [© OpenStreetMap contributors](https://www.openstreetmap.org/copyright) · [Cruzamento no mapa](https://www.openstreetmap.org/#map=19/-23.59556/-46.59738)
- Os dois pontos do córrego Ipiranga foram aproximados a partir das coordenadas dos postos citados no estudo publicado no XXV Simpósio Brasileiro de Recursos Hídricos. [Delimitação de manchas de inundação na Bacia do Córrego do Ipiranga](https://files.abrhidro.org.br/Sumarios/255/3056b3e9a4af9ca7a310a3c8e7b9dc43_d7c510c21c1d035bf7a03fcbbc14fbb8.pdf)
